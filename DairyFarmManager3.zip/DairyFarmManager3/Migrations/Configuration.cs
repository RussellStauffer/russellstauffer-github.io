namespace DairyFarmManager3.Migrations
{
    using Models;
    using System.Data.Entity.Migrations;

    internal sealed class Configuration : DbMigrationsConfiguration<DairyFarmManager3.Models.DairyFarmManager3Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(DairyFarmManager3.Models.DairyFarmManager3Context context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //
            context.Cows.AddOrUpdate(p => p.Id,
             new Cows()
             { Name = "Lulubelle", Id = 1,
                 Breed = "Holstein", Age = 10,
                 Feed = "Hay" },

            new Cows()
            { Name = "Betty", Id = 2,
                Breed = "Ayrshire", Age = 6,
                Feed = "Half/Half" },

            new Cows()
            { Name = "Sheila", Id = 3,
                Breed = "Holstein", Feed = "Special",
                Age = 8},

            new Cows()
            { Name = "Deborah", Id = 4,
                Age = 12, Feed = "Vetinary",
                Breed = "Jersey" },

            new Cows()
            { Name = "Loretta", Id = 5,
                Age = 3, Breed = "Holstein",
                Feed = "Grain"}
            );
                
            context.Feeds.AddOrUpdate(p => p.FeedType,

                new Feeds() { FeedId = 1, FeedType = "Hay",
                    FeedCost = 1.55 },
                new Feeds() { FeedId = 2, FeedType = "Half/Half",
                    FeedCost = 2.07 },
                new Feeds() { FeedId = 3, FeedType = "Special",
                    FeedCost = 1.76 },
                new Feeds() { FeedId = 4, FeedType = "Grain",
                    FeedCost = 2.58 },
                new Feeds() { FeedId = 5, FeedType = "Vetinary",
                    FeedCost = 2.54 }
            );
            context.Production.AddOrUpdate(p => p.CowId,

            new Productivity() { CowId = 1, CowName = "Lulubelle", FeedCost = 1.55, Production = 5.0, Price = 8.65, Profit = 7.10 },
            new Productivity() { CowId = 2, CowName = "Betty", FeedCost = 2.07, Production = 4.0, Price = 6.92, Profit = 4.85 },
            new Productivity() { CowId = 3, CowName = "Sheila",FeedCost = 1.76, Production = 6.0, Price =  10.38, Profit = 8.62},
            new Productivity() { CowId = 4, CowName = "Deborah", FeedCost = 2.54, Production = 5.0, Price = 8.65, Profit = 6.11 },
            new Productivity() { CowId = 5, CowName = "Loretta", FeedCost = 2.58, Production = 5.0, Price = 8.65, Profit =  6.07}
            );
            ;
        }
    }
}
