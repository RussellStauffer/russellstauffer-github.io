namespace DairyFarmManager3.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Initial : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Cows",
                c => new
                    {
                        Id = c.Int(nullable: false, identity: true),
                        Name = c.String(),
                        Breed = c.String(),
                        Feed = c.String(),
                        Age = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.Id);
            
            CreateTable(
                "dbo.Feeds",
                c => new
                    {
                        FeedId = c.Int(nullable: false, identity: true),
                        FeedType = c.String(),
                        FeedCost = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.FeedId);
            
            CreateTable(
                "dbo.Productivities",
                c => new
                    {
                        CowId = c.Int(nullable: false, identity: true),
                        CowName = c.String(),
                        FeedCost = c.Double(nullable: false),
                        Production = c.Double(nullable: false),
                        Price = c.Double(nullable: false),
                        Profit = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.CowId);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Productivities");
            DropTable("dbo.Feeds");
            DropTable("dbo.Cows");
        }
    }
}
