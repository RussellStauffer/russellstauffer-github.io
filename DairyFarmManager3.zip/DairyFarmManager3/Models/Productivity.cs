﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace DairyFarmManager3.Models
{
    public class Productivity
    {
        [Key]
        public int CowId { get; set; }
        [DisplayName("Name")]
        public string CowName { get; set; }
        [DisplayName("Feed Cost")]
        public double FeedCost { get; set; }
        [DisplayName("Milk Produced (gal)")]
        public double Production { get; set; }
        [DisplayName("Price of Milk")]
        public double Price { get; set; }
        [DisplayName("Profit")]
        public double Profit { get; set; }
    }
}