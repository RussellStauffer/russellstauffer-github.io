﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PapaBobs.DTO.Enums;

namespace PapaBobs.Web
{
    public partial class Default : System.Web.UI.Page
    {
        /*==================================================
         *  Papa Bob's Pizza Management Program
         *  
         *  Based on an original idea by Bob Tabor of 
         *  Dev U. 
         *  
         *  Author Russell Stauffer.
         *  Version 1.01
         *  
         *  Compiled on Visual Studio Community 2015
         *  Using C# programming language.
         *  
         *  Last backup section 10
         *  End of session - 07 AUG 2017,
         *  database worked in test:
         * -------------------------------------------------
         *   - All minimal requirements completed.
         *   
         *   - Suggest that Success screen be replaced with 
         *     Success message box. It would look more 
         *     professional.
         *     
         *   - The completed column might be replaced with
         *     a button in later versions. 
         *   
         ==================================================*/

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void orderButton_Click(object sender, EventArgs e)
        {
            // Insert validations here.
            // ------------------------
            // Check for name
            if (nameTextBox.Text.Trim().Length == 0)
            {
                validationLabel.Text = "Please enter your name.";
                validationLabel.Visible = true;
                return;
            }
            // Check for address
            if(addressTextBox.Text.Trim().Length == 0)
            {
                validationLabel.Text = "Please enter your address.";
                validationLabel.Visible = true;
                return;
            }
            // check for postal code (Zip Code)
            if (zipTextBox.Text.Trim().Length == 0)
            {
                validationLabel.Text = "Please enter your Zip code.";
                validationLabel.Visible = true;
                return;
            }
            // Check for phone number
            if(phoneTextBox.Text.Trim().Length == 0)
            {
                validationLabel.Text = "Please enter your phone number.";
                validationLabel.Visible = true;
                return;
            }

            // if all valid, process order.
            try
            {
                var order = buildOrder();
                Domain.OrderManager.CreateOrder(order);
                Response.Redirect("Success.aspx");

            }
            // if error, show error message
            catch (Exception ex)
            {
                validationLabel.Text = ex.Message;
                validationLabel.Visible = true;
                return;
            }

        }

        // Select and verify Payment type
        private DTO.Enums.PaymentType determinePaymentType()
        {
            DTO.Enums.PaymentType paymentType;

            if (cashRadioButton.Checked)
            {
                paymentType = DTO.Enums.PaymentType.Cash;
            }
            else
            {
                paymentType = DTO.Enums.PaymentType.Credit;
            }

            return paymentType;
        }

        // Select crust, check for error on crust selection
        private CrustType determineCrust()
        {
            DTO.Enums.CrustType crust;
            if (!Enum.TryParse(crustDropDownList.SelectedValue, out crust))
            {
                throw new Exception("could not determine Pizza crust");
            }
            return crust;
        }

        // Select size, check for error on size selection
        private DTO.Enums.SizeType determineSize()
        {
            DTO.Enums.SizeType size;
            if (!Enum.TryParse(sizeDropDownList.SelectedValue, out size))
            {
                throw new Exception("could not determine Pizza size");
            }
            return size;
        }

        // Recalculate the cost if any choices change.
        protected void recalculateTotalCost(object sender, EventArgs e)
        {
            // reset error to invisible here

            validationLabel.Visible = false;

            // check for not selected yet.
            if (sizeDropDownList.SelectedValue == String.Empty) return;
            if (crustDropDownList.SelectedValue == String.Empty) return;

            var order = buildOrder(); // rebuild order

            try
            {
                totalLabel.Text = Domain.PizzaPriceManager.CalculateCost(order).ToString("C");
            }
            catch
            {
                // Swallow the  error for now.
            }

        }

        private DTO.OrderDTO buildOrder()
        {
            var order = new DTO.OrderDTO();
            // Size and crust.
            order.Size = determineSize();
            order.Crust = determineCrust();

            // Ingredients
            order.Sausage = sausageCheckBox.Checked;
            order.Pepperoni = pepperoniCheckBox.Checked;
            order.Onions = onionCheckBox.Checked;
            order.GreenPeppers = greenPepperCheckBox.Checked;

            // User information
            order.Name = nameTextBox.Text;
            order.Address = addressTextBox.Text;
            order.Zip = zipTextBox.Text;
            order.Phone = phoneTextBox.Text;

            // Payment type
            order.PaymentType = determinePaymentType();

            return order;
        }
    }
}