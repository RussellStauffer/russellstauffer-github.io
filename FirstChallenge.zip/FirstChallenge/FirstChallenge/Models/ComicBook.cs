﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FirstChallenge.Models
{

    // The public class for Comic Book Information

    public class ComicBookManager
    {
        // In this example, we will simulate our data file. In a 
        // real world application, the data would be out in a file,
        // either in a server or a client file. (RS/10AUG2017)
        //
        public static List<ComicBook> GetComicBooks() {
            return new List<ComicBook> {
                new ComicBook {ComicBookId=1, ComicTitle="Action Comics", EpisodeNumber=41, EpisodeTitle="Not So Super Man", Characters = new List<Character>{ new Character { CharacterId=1, Name="Superman" }}},
                new ComicBook {ComicBookId=2, ComicTitle="Batman Superman", EpisodeNumber=13, EpisodeTitle="Crossways", Characters = new List<Character>{new Character {CharacterId=1, Name="Superman" }, new Character {CharacterId=2, Name="Batman"}}},
                new ComicBook {ComicBookId=3, ComicTitle="Arkham", EpisodeNumber=17, EpisodeTitle="Darkest Knight", Characters= new List<Character>{new Character {CharacterId=2, Name="Batman" }}},
                new ComicBook {ComicBookId=4, ComicTitle="Amazing Spiderman", EpisodeNumber=221, EpisodeTitle="Cat Scratch Fever", Characters = new List<Character> {new Character { CharacterId=3, Name="Spiderman"},new Character {CharacterId=4, Name="Black Cat"}}}
            };
        }
    }

    public class ComicBook
    {
        public int ComicBookId { get; set; }
        public string ComicTitle { get; set; }
        public int EpisodeNumber { get; set; }
        public string EpisodeTitle { get; set; }
        public List<Character> Characters { get; set; }
    }

    public class Character
    {
        public int CharacterId { get; set; }
        public string Name { get; set; }
    }
}